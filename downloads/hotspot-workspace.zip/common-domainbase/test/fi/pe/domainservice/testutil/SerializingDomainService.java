package fi.pe.domainservice.testutil;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Collection;
import java.util.Set;

import fi.pe.domain.Entity;
import fi.pe.domainservice.DomainService;
import fi.pe.domainservice.Projection;
import fi.pe.domainservice.Restriction;

public class SerializingDomainService implements DomainService {

	private final DomainService domainService;

	public SerializingDomainService(DomainService domainService) {
		this.domainService = domainService;
	}

	@Override
	public <T extends Entity<T>> T create(Class<T> entity) {
		byte[] bytes = toBytes(entity);
		// System.out.println("<<< Create " + bytes.length + " bytes >>>");
		Class<T> serilizedEntity = (Class<T>) fromBytes(bytes);

		T result = domainService.create(serilizedEntity);
		bytes = toBytes(result);
		// System.out.println("<<< Result " + bytes.length + " bytes >>>");
		return (T) fromBytes(bytes);
	}

	@Override
	public <T extends Entity<T>> T save(T entity) {
		byte[] bytes = toBytes(entity);
		// System.out.println("<<< Save " + bytes.length + " bytes >>>");
		T serilizedEntity = (T) fromBytes(bytes);

		T result = domainService.save(serilizedEntity);
		bytes = toBytes(result);
		// System.out.println("<<< Result " + bytes.length + " bytes >>>");
		return (T) fromBytes(bytes);
	}

	@Override
	public <T extends Entity<T>> Set<T> execute(Class<T> entity,
			Collection<Projection> projections, Collection<Restriction> restrictions) {
		byte[] bytes1 = toBytes(entity);
		byte[] bytes2 = toBytes(projections);
		byte[] bytes3 = toBytes(restrictions);
		// System.out.println("<<< Query " + (bytes1.length + bytes2.length +
		// bytes3.length)+ " bytes >>>");
		Class<T> serializedEntity = (Class<T>) fromBytes(bytes1);
		Collection<Projection> serializedProjections = (Collection<Projection>) fromBytes(bytes2);
		Collection<Restriction> serializedRestrictions = (Collection<Restriction>) fromBytes(bytes3);

		Set<T> result = domainService.execute(serializedEntity, serializedProjections,
				serializedRestrictions);
		bytes1 = toBytes(result);
		// System.out.println("<<< Result " + bytes1.length + " bytes >>>");
		return (Set<T>) fromBytes(bytes1);
	}

	private byte[] toBytes(Object object) {
		try {
			ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
			ObjectOutputStream out = new ObjectOutputStream(bytesOut);
			out.writeObject(object);
			return bytesOut.toByteArray();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private Object fromBytes(byte[] bytes) {
		try {
			ByteArrayInputStream bytesIn = new ByteArrayInputStream(bytes);
			ObjectInputStream in = new ObjectInputStream(bytesIn);
			return in.readObject();
		} catch (IOException e) {
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}
}
