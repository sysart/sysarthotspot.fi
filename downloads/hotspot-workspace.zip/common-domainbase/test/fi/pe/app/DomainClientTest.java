package fi.pe.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;
import java.util.Set;

import org.h2.jdbcx.JdbcConnectionPool;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import fi.pe.app.domain.Address;
import fi.pe.app.domain.AddressQuery;
import fi.pe.app.domain.Customer;
import fi.pe.app.domain.CustomerQuery;
import fi.pe.app.domain.Order;
import fi.pe.app.domain.OrderQuery;
import fi.pe.app.domain.impl.AppDomainContext;
import fi.pe.app.server.AppDataMapper;
import fi.pe.app.server.AppEntityFactory;
import fi.pe.domain.DomainContext;
import fi.pe.domainservice.simple.SimpleDomainService;
import fi.pe.domainservice.testutil.SerializingDomainService;

public class DomainClientTest {

	private DomainContext domainContext = null;
	private DatabaseTool databaseTool = null;
	private JdbcConnectionPool pool = null;

	@Before
	public void setUp() throws SQLException {
		AppDataMapper dataMapper = new AppDataMapper();
		pool = JdbcConnectionPool.create("jdbc:h2:mem:", "", "");
		databaseTool = new DatabaseTool(dataMapper, pool);
		databaseTool.createTestDatabase();
		domainContext = new AppDomainContext(new SerializingDomainService(new SimpleDomainService(
				pool, dataMapper, new AppEntityFactory())));
	}

	@After
	public void tearDown() throws SQLException {
		pool.dispose();
		domainContext = null;
		databaseTool = null;
	}

	@Test
	public void testCreateSaveAndLoad() {
		Customer customer = domainContext.create(Customer.class);
		assertNotNull(customer.id());
		customer.name().set("Asiakas Testi");
		customer.age().set(35);

		Address address = domainContext.create(Address.class);
		assertNotNull(address.id());
		address.street().set("Polku 15");
		address.zipCode().set(90450);
		customer.address().set(address);
		domainContext.save(customer);

		CustomerQuery query = domainContext.create(CustomerQuery.class);
		query.id().eq(customer.id());
		query.name().fetch();
		query.age().fetch();
		query.address().street().fetch();
		query.address().zipCode().fetch();
		Set<Customer> result = domainContext.execute(query);
		assertEquals(1, result.size());

		customer = result.iterator().next();
		assertEquals("Asiakas Testi", customer.name().get());
		assertEquals(Integer.valueOf(35), customer.age().get());

		address = customer.address().get();
		assertEquals("Polku 15", address.street().get());
		assertEquals(Integer.valueOf(90450), address.zipCode().get());
	}

	@Test
	public void testListCustomers() throws SQLException {
		databaseTool.createTestData();

		CustomerQuery query = domainContext.create(CustomerQuery.class);
		query.name().like("Mu%").fetch();
		query.age().fetch();
		query.address().zipCode().eq(888).fetch();
		query.orders().date().fetch();
		query.orders().count().fetch();
		Set<Customer> result = domainContext.execute(query);
		assertEquals(1, result.size());

		Customer customer = result.iterator().next();
		assertEquals("Muumi", customer.name().get());
		assertEquals(Integer.valueOf(16), customer.age().get());
		assertEquals("", customer.address().get().street().get());
		for (Order order : customer.orders()) {
			assertNotNull(order.date().get());
			assertNotNull(order.count().get());
		}
	}

	@Test
	public void testListAddresses() throws SQLException {
		databaseTool.createTestData();

		AddressQuery query = domainContext.create(AddressQuery.class);
		query.zipCode().eq(99900).fetch();
		query.customer().name().fetch();
		Set<Address> result = domainContext.execute(query);
		assertEquals(1, result.size());

		Address address = result.iterator().next();
		assertEquals(Integer.valueOf(99900), address.zipCode().get());
		assertEquals("Muumi", address.customer().get().name().get());
	}

	@Test
	public void testListOrders() throws SQLException {
		databaseTool.createTestData();

		OrderQuery query = domainContext.create(OrderQuery.class);
		query.customer().name().like("M%").fetch();
		query.date().fetch();
		Set<Order> result = domainContext.execute(query);
		assertEquals(2, result.size());

		for (Order order : result) {
			assertNotNull(order.id());
			assertNotNull(order.date().get());
			assertNotNull(order.customer().get().name().get());
		}
	}
}
