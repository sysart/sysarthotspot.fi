package fi.pe.app;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.UUID;

import org.h2.jdbcx.JdbcConnectionPool;

import fi.pe.app.domain.Address;
import fi.pe.app.domain.Customer;
import fi.pe.app.domain.Order;
import fi.pe.app.server.AppDataMapper;
import fi.pe.domain.Entity;

public class DatabaseTool {

	private final AppDataMapper dataMapper;
	private final JdbcConnectionPool pool;

	public DatabaseTool(AppDataMapper dataMapper, JdbcConnectionPool pool) {
		this.dataMapper = dataMapper;
		this.pool = pool;
	}

	public void createTestDatabase() throws SQLException {
		Connection connection = pool.getConnection();
		createTables(connection);
		connection.close();
	}

	public void createTestData() throws SQLException {
		Connection connection = pool.getConnection();
		createData(connection);
		connection.close();
	}

	private void createTables(Connection connection) throws SQLException {
		Statement statement = connection.createStatement();
		statement
				.executeUpdate(createTable(Customer.class, Customer.Field.Name, Customer.Field.Age));
		statement.executeUpdate(createTable(Address.class, Address.Field.Customer,
				Address.Field.Street, Address.Field.ZipCode));
		statement.executeUpdate(createTable(Order.class, Order.Field.Customer, Order.Field.Date,
				Order.Field.Count));
		statement.close();
	}

	private <T extends Entity<T>> String createTable(Class<T> entity, Object... fields) {
		StringBuilder sb = new StringBuilder();
		sb.append("create table ");
		sb.append(dataMapper.getTableName(entity));
		sb.append(" (");
		sb.append(dataMapper.getColumnName(entity, Entity.Field.Id));
		sb.append(" ");
		sb.append(dataMapper.getColumnType(entity, Entity.Field.Id));
		for (Object field : fields) {
			sb.append(",");
			sb.append(dataMapper.getColumnName(entity, field));
			sb.append(" ");
			sb.append(dataMapper.getColumnType(entity, field));
		}
		sb.append(")");
		return sb.toString();
	}

	private void createData(Connection connection) throws SQLException {
		Statement statement = connection.createStatement();
		String key1 = getUUID();
		String key2 = getUUID();
		String key3 = getUUID();
		statement.executeUpdate(createData(Customer.class, key1, "Asiakas", "25"));
		statement.executeUpdate(createData(Customer.class, key2, "Mylläri", "70"));
		statement.executeUpdate(createData(Customer.class, key3, "Muumi", "16"));

		statement.executeUpdate(createData(Address.class, getUUID(), key2, "Tienhaara", "99900"));
		statement.executeUpdate(createData(Address.class, getUUID(), key3, "Kesäkatu", "12300"));

		statement.executeUpdate(createData(Order.class, getUUID(), key1, new Date(), "4"));
		statement.executeUpdate(createData(Order.class, getUUID(), key2, new Date(), "1"));
		statement.executeUpdate(createData(Order.class, getUUID(), key3, new Date(), "7"));
		statement.close();
	}

	private String getUUID() {
		return UUID.randomUUID().toString();
	}

	private <T extends Entity<T>> String createData(Class<T> entity, Object... values) {
		StringBuilder sb = new StringBuilder();
		sb.append("insert into ");
		sb.append(dataMapper.getTableName(entity));
		sb.append(" values (");
		for (Object object : values) {
			sb.append("'");
			sb.append(object);
			sb.append("',");
		}
		sb.deleteCharAt(sb.length() - 1);
		sb.append(")");
		return sb.toString();
	}
}
