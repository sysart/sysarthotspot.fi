package fi.pe.domain;

import java.io.Serializable;

public interface EntityProperty<T> extends Serializable {

	T get();

	void set(T value);

}
