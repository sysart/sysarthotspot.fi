package fi.pe.domain;

import java.io.Serializable;

public interface EntityKey<T> extends Serializable {

}
