package fi.pe.domain;

import java.io.Serializable;

public interface EntitySet<T extends Entity<T>> extends Iterable<T>, Serializable {

	void add(T entity);

	void add(EntityReference<T> entityReference);

	// void add(EntityInstance<T> entityInstance);

}
