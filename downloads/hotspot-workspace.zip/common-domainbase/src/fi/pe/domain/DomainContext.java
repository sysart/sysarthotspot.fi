package fi.pe.domain;

import java.util.Set;

public interface DomainContext {

	<T extends Entity<T>> T create(Class<T> entity);

	<T extends Entity<T>> T save(T entity);

	<T extends Query<?>> T create(Class<T> query);

	<T extends Entity<T>> Set<T> execute(Query<T> query);

}
