package fi.pe.domain;

import java.io.Serializable;

public interface Entity<T> extends Serializable {

	enum Field {
		Id
	}

	EntityKey<T> id();

}
