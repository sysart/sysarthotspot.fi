package fi.pe.domain;

import java.io.Serializable;

public interface EntityReference<T extends Entity<T>> extends Serializable {

	T get();

	void set(T entity);

	void set(EntityReference<T> entityReference);

	// void set(EntityInstance<T> entityInstance);

}
