package fi.pe.domain.impl;

import java.util.Collections;
import java.util.List;

public class LikeRestriction extends AbstractRestriction {

	private final String value;

	public LikeRestriction(Object key, String value) {
		super(key);
		this.value = value;
	}

	@Override
	public String getOperand() {
		return "like ?";
	}

	@Override
	public List<Object> getValues() {
		return Collections.singletonList((Object) value);
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + "[" + getKey() + " like '" + value + "']";
	}
}
