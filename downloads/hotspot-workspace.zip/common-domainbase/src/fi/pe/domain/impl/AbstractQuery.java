package fi.pe.domain.impl;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import fi.pe.domain.DomainContext;
import fi.pe.domain.EntityKey;
import fi.pe.domain.Query;
import fi.pe.domain.QueryProperty;
import fi.pe.domainservice.Projection;
import fi.pe.domainservice.Restriction;

public abstract class AbstractQuery<T> implements Query<T> {

	private transient final DomainContext domainContext;
	private final Class<T> baseEntity;
	private Map<Object, DefaultQueryProperty<?>> propertys;
	private Map<Object, AbstractQuery<?>> queries;

	public AbstractQuery(Class<T> baseEntity, DomainContext domainContext) {
		this.baseEntity = baseEntity;
		this.domainContext = domainContext;
	}

	@Override
	public QueryProperty<EntityKey<T>> id() {
		return getQueryProperty("id");
	}

	protected <K> QueryProperty<K> getQueryProperty(Object name) {
		if (propertys == null) propertys = new HashMap<Object, DefaultQueryProperty<?>>();
		DefaultQueryProperty<?> property = propertys.get(name);
		if (property == null) {
			property = new DefaultQueryProperty<K>(name);
			propertys.put(name, property);
		}
		return (QueryProperty<K>) property;
	}

	protected <K extends Query<?>> K getQuery(Object key, Class<K> queryClass) {
		if (queries == null) queries = new HashMap<Object, AbstractQuery<?>>();
		AbstractQuery<?> query = queries.get(key);
		if (query == null) {
			query = (AbstractQuery<?>) domainContext.create(queryClass);
			queries.put(key, query);
		}
		return (K) query;
	}

	public Class<T> getBaseEntity() {
		return baseEntity;
	}

	public Set<Projection> getProjections() {
		Set<Projection> result = new HashSet<Projection>();
		if (propertys != null) {
			for (DefaultQueryProperty<?> property : propertys.values())
				if (property.getProjection() != null) result.add(property.getProjection());
		}
		if (queries != null) {
			for (Entry<Object, AbstractQuery<?>> entry : queries.entrySet()) {
				Collection<Projection> queryProjections = entry.getValue().getProjections();
				for (Projection projection : queryProjections) {
					result.add(new ChainProjection(entry.getKey(), projection));
				}
			}
		}
		return result;
	}

	public Set<Restriction> getRestrictions() {
		Set<Restriction> result = new HashSet<Restriction>();
		if (propertys != null) {
			for (DefaultQueryProperty<?> property : propertys.values())
				if (property.getRestriction() != null) result.add(property.getRestriction());
		}
		if (queries != null) {
			for (Entry<Object, AbstractQuery<?>> entry : queries.entrySet()) {
				Collection<Restriction> queryRestrictions = entry.getValue().getRestrictions();
				for (Restriction restriction : queryRestrictions) {
					result.add(new ChainRestriction(entry.getKey(), restriction));
				}
			}
		}
		return result;
	}
}
