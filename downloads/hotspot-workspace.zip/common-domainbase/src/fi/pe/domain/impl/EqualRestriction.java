package fi.pe.domain.impl;

import java.util.Collections;
import java.util.List;

public class EqualRestriction extends AbstractRestriction {

	private final Object value;

	public EqualRestriction(Object key, Object value) {
		super(key);
		this.value = value;
	}

	@Override
	public String getOperand() {
		return "= ?";
	}

	@Override
	public List<Object> getValues() {
		return Collections.singletonList(value);
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + "[" + getKey() + " = " + value + "]";
	}
}
