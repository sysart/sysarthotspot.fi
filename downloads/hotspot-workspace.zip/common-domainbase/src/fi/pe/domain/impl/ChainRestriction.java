package fi.pe.domain.impl;

import java.util.List;

import fi.pe.domainservice.Restriction;

public class ChainRestriction implements Restriction {

	private final Object key;
	private final Restriction childRestriction;

	public ChainRestriction(Object key, Restriction childRestriction) {
		this.key = key;
		this.childRestriction = childRestriction;
	}

	@Override
	public List<Object> getKeys() {
		List<Object> keys = childRestriction.getKeys();
		keys.add(0, key);
		return keys;
	}

	@Override
	public String getOperand() {
		throw new UnsupportedOperationException();
	}

	@Override
	public List<Object> getValues() {
		throw new UnsupportedOperationException();
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + " - " + key + " -> " + childRestriction;
	}
}
