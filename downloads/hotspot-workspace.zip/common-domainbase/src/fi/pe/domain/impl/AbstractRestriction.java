package fi.pe.domain.impl;

import java.util.ArrayList;
import java.util.List;

import fi.pe.domainservice.Restriction;

public abstract class AbstractRestriction implements Restriction {

	private final Object key;

	public AbstractRestriction(Object key) {
		this.key = key;
	}

	public Object getKey() {
		return key;
	}

	@Override
	public List<Object> getKeys() {
		List<Object> list = new ArrayList<Object>();
		list.add(key);
		return list;
	}

}
