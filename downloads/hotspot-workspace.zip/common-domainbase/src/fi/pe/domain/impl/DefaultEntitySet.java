package fi.pe.domain.impl;

import java.util.Collections;
import java.util.Iterator;
import java.util.Set;

import fi.pe.domain.Entity;
import fi.pe.domain.EntityReference;
import fi.pe.domain.EntitySet;

public class DefaultEntitySet<T extends Entity<T>> implements EntitySet<T> {

	public DefaultEntitySet(Set<T> set) {
	}

	@Override
	public void add(T entity) {
	}

	@Override
	public void add(EntityReference<T> entityReference) {
	}

	@Override
	public Iterator<T> iterator() {
		return Collections.<T> emptySet().iterator();
	}
}
