package fi.pe.domain.impl;

import fi.pe.domain.EntityProperty;

public class DefaultEntityProperty<T> implements EntityProperty<T> {

	private T value;

	public DefaultEntityProperty(T value) {
		this.value = value;
	}

	@Override
	public T get() {
		return value;
	}

	@Override
	public void set(T value) {
		this.value = value;
	};

}
