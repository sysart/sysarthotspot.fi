package fi.pe.domain.impl;

import fi.pe.domain.Entity;
import fi.pe.domain.EntityReference;

public class DefaultEntityReference<T extends Entity<T>> implements EntityReference<T> {

	private T value;

	public DefaultEntityReference(T value) {
		this.value = value;
	}

	@Override
	public T get() {
		return value;
	}

	@Override
	public void set(T value) {
		this.value = value;
	};

	@Override
	public void set(EntityReference<T> value) {
		set(value.get());
	}
}
