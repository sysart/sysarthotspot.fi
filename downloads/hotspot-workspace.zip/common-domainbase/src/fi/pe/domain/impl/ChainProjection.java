package fi.pe.domain.impl;

import java.util.List;

import fi.pe.domainservice.Projection;

public class ChainProjection implements Projection {

	private final Object key;
	private final Projection childProjection;

	public ChainProjection(Object key, Projection childProjection) {
		this.key = key;
		this.childProjection = childProjection;
	}

	@Override
	public List<Object> getKeys() {
		List<Object> keys = childProjection.getKeys();
		keys.add(0, key);
		return keys;
	}

	@Override
	public String toString() {
		return super.toString() + " -> " + childProjection;
	}

}
