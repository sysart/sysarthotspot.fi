package fi.pe.domain.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import fi.pe.domain.Entity;
import fi.pe.domain.EntityKey;
import fi.pe.domain.EntityProperty;
import fi.pe.domain.EntityReference;
import fi.pe.domain.EntitySet;

public abstract class AbstractEntity<T> implements Entity<T> {

	private final EntityKey<T> id;
	private final boolean allowNullGets;
	private final Map<Object, Object> data;
	private final Map<Object, Object> cache;

	public AbstractEntity(EntityKey<T> id, boolean allowNullGets, Map<Object, Object> data) {
		this.id = id;
		this.allowNullGets = allowNullGets;
		this.data = data;
		this.cache = new HashMap<Object, Object>();
	}

	@Override
	public EntityKey<T> id() {
		return id;
	}

	protected <K> EntityProperty<K> getProperty(Object key, Class<K> type) {
		EntityProperty<K> property = (EntityProperty<K>) cache.get(key);
		if (property == null) {
			K dataValue = (K) data.get(key);
			if (dataValue == null && !allowNullGets)
				throw new NullPointerException(key + " not fetched");
			property = new DefaultEntityProperty<K>(dataValue);
			cache.put(key, property);
		}
		return property;
	}

	protected <K extends Entity<K>> EntityReference<K> getReference(Object key, Class<K> type) {
		EntityReference<K> reference = (EntityReference<K>) cache.get(key);
		if (reference == null) {
			K dataValue = (K) data.get(key);
			if (dataValue == null && !allowNullGets)
				throw new NullPointerException(key + " not fetched");
			reference = new DefaultEntityReference<K>(dataValue);
			cache.put(key, reference);
		}
		return reference;
	}

	protected <K extends Entity<K>> EntitySet<K> getSet(Object key, Class<K> type) {
		EntitySet<K> set = (EntitySet<K>) cache.get(key);
		if (set == null) {
			Set<K> dataValue = (Set<K>) data.get(key);
			if (dataValue == null && !allowNullGets)
				throw new NullPointerException(key + " not fetched");
			set = new DefaultEntitySet<K>(dataValue);
			cache.put(key, set);
		}
		return set;
	}

}
