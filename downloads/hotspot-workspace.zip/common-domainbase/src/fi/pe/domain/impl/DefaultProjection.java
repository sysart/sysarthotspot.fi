package fi.pe.domain.impl;

import java.util.ArrayList;
import java.util.List;

import fi.pe.domainservice.Projection;

public class DefaultProjection implements Projection {

	private final Object key;

	public DefaultProjection(Object key) {
		this.key = key;
	}

	@Override
	public List<Object> getKeys() {
		List<Object> list = new ArrayList<Object>();
		list.add(key);
		return list;
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + " - " + key;
	}
}
