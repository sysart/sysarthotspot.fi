package fi.pe.domain.impl;

import java.util.Set;

import fi.pe.domain.QueryProperty;
import fi.pe.domainservice.Projection;
import fi.pe.domainservice.Restriction;

public class DefaultQueryProperty<T> implements QueryProperty<T> {

	private final Object name;
	private Projection projection = null;
	private Restriction restriction = null;

	public DefaultQueryProperty(Object name) {
		this.name = name;
	}

	@Override
	public QueryProperty<T> eq(T value) {
		restriction = new EqualRestriction(name, value);
		return this;
	}

	@Override
	public QueryProperty<T> in(Set<T> values) {
		return this;
	}

	@Override
	public QueryProperty<T> like(String value) {
		restriction = new LikeRestriction(name, value);
		return this;
	}

	@Override
	public QueryProperty<T> greaterOrEqual(T value) {
		return this;
	}

	@Override
	public void fetch() {
		projection = new DefaultProjection(name);
	}

	public Projection getProjection() {
		return projection;
	}

	public Restriction getRestriction() {
		return restriction;
	}
}
