package fi.pe.domain;

import java.io.Serializable;

public interface Query<T> extends Serializable {

	QueryProperty<EntityKey<T>> id();

}
