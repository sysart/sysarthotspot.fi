package fi.pe.domain;

import java.io.Serializable;
import java.util.Set;

public interface QueryProperty<T> extends Serializable {

	QueryProperty<T> eq(T value);

	QueryProperty<T> in(Set<T> values);

	QueryProperty<T> like(String value);

	QueryProperty<T> greaterOrEqual(T value);

	void fetch();

}
