package fi.pe.app.domain.impl;

import java.util.Date;
import java.util.Map;

import fi.pe.app.domain.Customer;
import fi.pe.app.domain.Order;
import fi.pe.domain.EntityKey;
import fi.pe.domain.EntityProperty;
import fi.pe.domain.EntityReference;
import fi.pe.domain.impl.AbstractEntity;

public class OrderImpl extends AbstractEntity<Order> implements Order {

	public OrderImpl(EntityKey<Order> id, boolean allowNullGets, Map<Object, Object> data) {
		super(id, allowNullGets, data);
	}

	@Override
	public EntityProperty<Integer> count() {
		return getProperty(Order.Field.Count, Integer.class);
	}

	@Override
	public EntityProperty<Date> date() {
		return getProperty(Order.Field.Date, Date.class);
	}

	@Override
	public EntityReference<Customer> customer() {
		return getReference(Order.Field.Customer, Customer.class);
	}
}
