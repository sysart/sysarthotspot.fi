package fi.pe.app.domain;

import fi.pe.domain.Entity;
import fi.pe.domain.EntityProperty;
import fi.pe.domain.EntityReference;

public interface Address extends Entity<Address> {

	enum Field {
		Customer, Street, ZipCode
	}

	EntityReference<Customer> customer();

	EntityProperty<String> street();

	EntityProperty<Integer> zipCode();

}
