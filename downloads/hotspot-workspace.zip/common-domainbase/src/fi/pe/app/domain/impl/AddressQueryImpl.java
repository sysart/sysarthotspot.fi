package fi.pe.app.domain.impl;

import fi.pe.app.domain.Address;
import fi.pe.app.domain.AddressQuery;
import fi.pe.app.domain.CustomerQuery;
import fi.pe.domain.DomainContext;
import fi.pe.domain.QueryProperty;
import fi.pe.domain.impl.AbstractQuery;

public class AddressQueryImpl extends AbstractQuery<Address> implements AddressQuery {

	public AddressQueryImpl(DomainContext domainContext) {
		super(Address.class, domainContext);
	}

	@Override
	public CustomerQuery customer() {
		return getQuery(Address.Field.Customer, CustomerQuery.class);
	}

	@Override
	public QueryProperty<String> street() {
		return getQueryProperty(Address.Field.Street);
	}

	@Override
	public QueryProperty<Integer> zipCode() {
		return getQueryProperty(Address.Field.ZipCode);
	}
}
