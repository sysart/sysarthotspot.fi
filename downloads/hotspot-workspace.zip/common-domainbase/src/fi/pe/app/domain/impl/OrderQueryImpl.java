package fi.pe.app.domain.impl;

import java.util.Date;

import fi.pe.app.domain.CustomerQuery;
import fi.pe.app.domain.Order;
import fi.pe.app.domain.OrderQuery;
import fi.pe.domain.DomainContext;
import fi.pe.domain.QueryProperty;
import fi.pe.domain.impl.AbstractQuery;

public class OrderQueryImpl extends AbstractQuery<Order> implements OrderQuery {

	public OrderQueryImpl(DomainContext domainContext) {
		super(Order.class, domainContext);
	}

	@Override
	public CustomerQuery customer() {
		return getQuery(Order.Field.Customer, CustomerQuery.class);
	}

	@Override
	public QueryProperty<Date> date() {
		return getQueryProperty(Order.Field.Date);
	}

	@Override
	public QueryProperty<Integer> count() {
		return getQueryProperty(Order.Field.Count);
	}
}
