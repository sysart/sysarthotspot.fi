package fi.pe.app.domain.impl;

import fi.pe.app.domain.AddressQuery;
import fi.pe.app.domain.Customer;
import fi.pe.app.domain.CustomerQuery;
import fi.pe.app.domain.OrderQuery;
import fi.pe.domain.DomainContext;
import fi.pe.domain.QueryProperty;
import fi.pe.domain.impl.AbstractQuery;

public class CustomerQueryImpl extends AbstractQuery<Customer> implements CustomerQuery {

	public CustomerQueryImpl(DomainContext domainContext) {
		super(Customer.class, domainContext);
	}

	@Override
	public QueryProperty<String> name() {
		return getQueryProperty(Customer.Field.Name);
	}

	@Override
	public QueryProperty<Integer> age() {
		return getQueryProperty(Customer.Field.Age);
	}

	@Override
	public AddressQuery address() {
		return getQuery(Customer.Field.Address, AddressQuery.class);
	}

	@Override
	public OrderQuery orders() {
		return getQuery(Customer.Field.Orders, OrderQuery.class);
	}
}
