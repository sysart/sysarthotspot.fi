package fi.pe.app.domain;

import fi.pe.domain.Query;
import fi.pe.domain.QueryProperty;

public interface AddressQuery extends Query<Address> {

	CustomerQuery customer();

	QueryProperty<String> street();

	QueryProperty<Integer> zipCode();

}
