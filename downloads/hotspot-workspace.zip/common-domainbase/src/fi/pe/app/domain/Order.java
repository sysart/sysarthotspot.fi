package fi.pe.app.domain;

import java.util.Date;

import fi.pe.domain.Entity;
import fi.pe.domain.EntityProperty;
import fi.pe.domain.EntityReference;

public interface Order extends Entity<Order> {

	enum Field {
		Customer, Date, Count
	}

	EntityReference<Customer> customer();

	EntityProperty<Date> date();

	EntityProperty<Integer> count();

}
