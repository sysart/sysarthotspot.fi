package fi.pe.app.domain.impl;

import fi.pe.domain.EntityKey;

public class StringEntityKey<T> implements EntityKey<T> {

	private final String value;

	private StringEntityKey(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public static <T> EntityKey<T> from(String value, Class<T> entityClass) {
		return new StringEntityKey<T>(value);
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + "[" + value + "]";
	}
}
