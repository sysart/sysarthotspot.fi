package fi.pe.app.domain.impl;

import java.util.Map;

import fi.pe.app.domain.Address;
import fi.pe.app.domain.Customer;
import fi.pe.app.domain.Order;
import fi.pe.domain.EntityKey;
import fi.pe.domain.EntityProperty;
import fi.pe.domain.EntityReference;
import fi.pe.domain.EntitySet;
import fi.pe.domain.impl.AbstractEntity;

public class CustomerImpl extends AbstractEntity<Customer> implements Customer {

	public CustomerImpl(EntityKey<Customer> id, boolean allowNullGets, Map<Object, Object> data) {
		super(id, allowNullGets, data);
	}

	@Override
	public EntityProperty<String> name() {
		return getProperty(Customer.Field.Name, String.class);
	}

	@Override
	public EntityProperty<Integer> age() {
		return getProperty(Customer.Field.Age, Integer.class);
	}

	@Override
	public EntityReference<Address> address() {
		return getReference(Customer.Field.Address, Address.class);
	}

	@Override
	public EntitySet<Order> orders() {
		return getSet(Customer.Field.Orders, Order.class);
	}
}
