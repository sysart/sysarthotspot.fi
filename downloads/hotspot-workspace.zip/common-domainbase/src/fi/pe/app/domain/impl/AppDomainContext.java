package fi.pe.app.domain.impl;

import java.util.Set;

import fi.pe.app.domain.AddressQuery;
import fi.pe.app.domain.CustomerQuery;
import fi.pe.app.domain.OrderQuery;
import fi.pe.domain.DomainContext;
import fi.pe.domain.Entity;
import fi.pe.domain.Query;
import fi.pe.domain.impl.AbstractQuery;
import fi.pe.domainservice.DomainService;

public class AppDomainContext implements DomainContext {

	private final DomainService domainService;

	public AppDomainContext(DomainService domainService) {
		this.domainService = domainService;
	}

	@Override
	public <T extends Entity<T>> T create(Class<T> entity) {
		if (entity == null) throw new NullPointerException();
		return domainService.create(entity);
	}

	@Override
	public <T extends Entity<T>> T save(T entity) {
		if (entity == null) throw new NullPointerException();
		return domainService.save(entity);
	}

	@Override
	public <T extends Query<?>> T create(Class<T> query) {
		if (query == null) throw new NullPointerException();
		if (CustomerQuery.class.equals(query)) return (T) new CustomerQueryImpl(this);
		if (AddressQuery.class.equals(query)) return (T) new AddressQueryImpl(this);
		if (OrderQuery.class.equals(query)) return (T) new OrderQueryImpl(this);
		throw new RuntimeException("Invalid query class");
	}

	@Override
	public <T extends Entity<T>> Set<T> execute(Query<T> query) {
		AbstractQuery<T> queryImpl = (AbstractQuery<T>) query;
		return domainService.execute(queryImpl.getBaseEntity(), queryImpl.getProjections(),
				queryImpl.getRestrictions());
	}
}
