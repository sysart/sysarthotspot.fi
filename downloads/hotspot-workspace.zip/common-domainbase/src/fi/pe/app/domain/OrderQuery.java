package fi.pe.app.domain;

import java.util.Date;

import fi.pe.domain.Query;
import fi.pe.domain.QueryProperty;

public interface OrderQuery extends Query<Order> {

	CustomerQuery customer();

	QueryProperty<Date> date();

	QueryProperty<Integer> count();

}
