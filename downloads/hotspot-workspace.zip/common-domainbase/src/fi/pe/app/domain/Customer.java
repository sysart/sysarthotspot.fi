package fi.pe.app.domain;

import fi.pe.domain.Entity;
import fi.pe.domain.EntityProperty;
import fi.pe.domain.EntityReference;
import fi.pe.domain.EntitySet;

public interface Customer extends Entity<Customer> {

	enum Field {
		Name, Age, Address, Orders
	};

	EntityProperty<String> name();

	EntityProperty<Integer> age();

	EntityReference<Address> address();

	EntitySet<Order> orders();

}
