package fi.pe.app.domain.impl;

import java.util.Map;

import fi.pe.app.domain.Address;
import fi.pe.app.domain.Customer;
import fi.pe.domain.EntityKey;
import fi.pe.domain.EntityProperty;
import fi.pe.domain.EntityReference;
import fi.pe.domain.impl.AbstractEntity;

public class AddressImpl extends AbstractEntity<Address> implements Address {

	public AddressImpl(EntityKey<Address> id, boolean allowNullGets, Map<Object, Object> data) {
		super(id, allowNullGets, data);
	}

	@Override
	public EntityReference<Customer> customer() {
		return getReference(Address.Field.Customer, Customer.class);
	}

	@Override
	public EntityProperty<String> street() {
		return getProperty(Address.Field.Street, String.class);
	}

	@Override
	public EntityProperty<Integer> zipCode() {
		return getProperty(Address.Field.ZipCode, Integer.class);
	}
}
