package fi.pe.app.domain;

import fi.pe.domain.Query;
import fi.pe.domain.QueryProperty;

public interface CustomerQuery extends Query<Customer> {

	QueryProperty<String> name();

	QueryProperty<Integer> age();

	AddressQuery address();

	OrderQuery orders();

}
