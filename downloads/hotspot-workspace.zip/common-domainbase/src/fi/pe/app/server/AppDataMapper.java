package fi.pe.app.server;

import java.util.HashMap;
import java.util.Map;

import fi.pe.app.domain.Address;
import fi.pe.app.domain.Customer;
import fi.pe.app.domain.Order;
import fi.pe.domain.Entity;
import fi.pe.domainservice.simple.DataMapper;

public class AppDataMapper implements DataMapper {

	private final Map<Class<?>, String> tables;
	private final Map<Object, String> types;
	private final Map<Object, Class<?>> references;

	public AppDataMapper() {
		tables = new HashMap<Class<?>, String>();
		types = new HashMap<Object, String>();
		references = new HashMap<Object, Class<?>>();
		initializeTables();
		initializeTypes();
		initializeReferences();
	}

	private void initializeTables() {
		tables.put(Customer.class, "customer");
		tables.put(Address.class, "customer_address");
		tables.put(Order.class, "orders");
	}

	private void initializeTypes() {
		types.put(Customer.Field.Age, "int");
		types.put(Address.Field.ZipCode, "int");
	}

	private void initializeReferences() {
		references.put(Customer.Field.Address, Address.class);
		references.put(Customer.Field.Orders, Order.class);
	}

	@Override
	public <T extends Entity<T>> String getTableName(Class<T> entity) {
		String table = tables.get(entity);
		if (table != null) return table;
		throw new RuntimeException("Unmapped table " + entity.getSimpleName());
	}

	@Override
	public <T extends Entity<T>> String getColumnName(Class<T> entity, Object key) {
		return key.toString().toLowerCase();
	}

	public <T extends Entity<T>> String getColumnType(Class<T> entity, Object key) {
		String type = types.get(key);
		if (type != null) return type;
		return "varchar(255)";
	}

	@Override
	public <T extends Entity<T>> Class<T> getReferenceTarget(Class<T> entity, Object key) {
		Class<?> reference = references.get(key);
		if (reference != null) return (Class<T>) reference;
		throw new RuntimeException("Unmapped reference " + entity.getSimpleName() + "." + key);
	}
}
