package fi.pe.app.server;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import fi.pe.app.domain.Address;
import fi.pe.app.domain.Customer;
import fi.pe.app.domain.Order;
import fi.pe.app.domain.impl.AddressImpl;
import fi.pe.app.domain.impl.CustomerImpl;
import fi.pe.app.domain.impl.OrderImpl;
import fi.pe.app.domain.impl.StringEntityKey;
import fi.pe.domain.Entity;
import fi.pe.domain.EntityKey;
import fi.pe.domainservice.simple.EntityFactory;

public class AppEntityFactory implements EntityFactory {

	@Override
	public <T extends Entity<T>> T create(Class<T> entity) {
		Map<Object, Object> data = new HashMap<Object, Object>();
		data.put(Entity.Field.Id, UUID.randomUUID().toString());
		return load(entity, true, data);
	}

	@Override
	public <T extends Entity<T>> T load(Class<T> entity, Map<Object, Object> data) {
		if (entity == null || data == null || data.isEmpty()) throw new NullPointerException();
		return load(entity, false, data);
	}

	private <T extends Entity<T>> T load(Class<T> entity, boolean allowNullGets,
			Map<Object, Object> data) {
		String id = (String) data.remove(Entity.Field.Id);
		if (Customer.class.equals(entity))
			return (T) new CustomerImpl(getKey(Customer.class, id), allowNullGets, data);
		if (Address.class.equals(entity))
			return (T) new AddressImpl(getKey(Address.class, id), allowNullGets, data);
		if (Order.class.equals(entity))
			return (T) new OrderImpl(getKey(Order.class, id), allowNullGets, data);
		throw new RuntimeException("Invalid entity class " + entity.getSimpleName());
	}

	private <T extends Entity<T>> EntityKey<T> getKey(Class<T> entity, String value) {
		return StringEntityKey.from(value, entity);
	}
}
