package fi.pe.domainservice.simple;

import fi.pe.domain.Entity;

public interface DataMapper {

	<T extends Entity<T>> String getTableName(Class<T> entity);

	<T extends Entity<T>> String getColumnName(Class<T> entity, Object key);

	<T extends Entity<T>> Class<T> getReferenceTarget(Class<T> entity, Object key);

}
