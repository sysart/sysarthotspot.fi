package fi.pe.domainservice.simple;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import fi.pe.domain.Entity;
import fi.pe.domainservice.DomainService;
import fi.pe.domainservice.Projection;
import fi.pe.domainservice.Restriction;

public class SimpleDomainService implements DomainService {

	private final DataSource dataSource;
	private final DataMapper dataMapper;
	private final EntityFactory entityFactory;

	public SimpleDomainService(DataSource dataSource, DataMapper dataMapper,
			EntityFactory entityFactory) {
		this.dataSource = dataSource;
		this.dataMapper = dataMapper;
		this.entityFactory = entityFactory;
	}

	@Override
	public <T extends Entity<T>> T create(Class<T> entity) {
		return entityFactory.create(entity);
	}

	@Override
	public <T extends Entity<T>> T save(T entity) {
		// TODO save
		return entity;
	}

	@Override
	public <T extends Entity<T>> Set<T> execute(Class<T> entity,
			Collection<Projection> projections, Collection<Restriction> restrictions) {
		if (entity == null) throw new NullPointerException();

		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			return executeQuery(connection, entity, projections, restrictions);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				if (connection != null) connection.close();
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}
	}

	private <T extends Entity<T>> Set<T> executeQuery(Connection connection, Class<T> entity,
			Collection<Projection> projections, Collection<Restriction> restrictions)
			throws SQLException {
		// 1. execute query with restrictions
		Set<Object> entityIds = fetchEntityIds(connection, entity, new ArrayList<Restriction>(
				restrictions));

		// 2. split projections per entity Map<key path, actual keys>
		Map<List<Object>, List<Object>> entityProjections = parseProjections(projections);

		// 3. fetch root entities according projections
		Set<T> entities = fetchEntities(connection, entity, entityProjections
				.remove(Collections.EMPTY_LIST), entityIds);

		// 4. fetch sub-entities according projections

		// 5. merge sub-entities

		return entities;
	}

	private Map<List<Object>, List<Object>> parseProjections(Collection<Projection> projections) {
		if (projections.isEmpty()) return Collections.emptyMap();

		Map<List<Object>, List<Object>> entityProjections = new HashMap<List<Object>, List<Object>>();
		for (Projection projection : projections) {
			List<Object> projectionKeys = projection.getKeys();
			List<Object> mapKey = projectionKeys.subList(0, projectionKeys.size() - 1);
			List<Object> mapValue = entityProjections.get(mapKey);
			if (mapValue == null) {
				mapValue = new ArrayList<Object>();
				entityProjections.put(mapKey, mapValue);
			}
			mapValue.add(projectionKeys.get(projectionKeys.size() - 1));
		}
		return entityProjections;
	}

	private <T extends Entity<T>> Set<Object> fetchEntityIds(Connection connection,
			Class<T> entity, List<Restriction> restrictions) throws SQLException {
		StringBuilder sb = new StringBuilder(128);
		sb.append("select ");
		sb.append(dataMapper.getColumnName(entity, Entity.Field.Id));
		sb.append(" from ");
		sb.append(dataMapper.getTableName(entity));

		List<Restriction> restrictionApplyOrder = new ArrayList<Restriction>();
		if (!restrictions.isEmpty()) {
			// split restrictions per entity Map<key path, actual keys>
			Map<List<Object>, List<Restriction>> entityRestrictions = parseRestrictions(restrictions);

			// join each entity

			List<Restriction> rootRestriction = entityRestrictions.get(Collections.EMPTY_LIST);
			if (rootRestriction != null && rootRestriction.size() > 0) {
				sb.append(" where ");
				for (Restriction restriction : rootRestriction) {
					restrictionApplyOrder.add(restriction);
					sb.append(dataMapper.getColumnName(entity, restriction.getKeys().get(
							restriction.getKeys().size() - 1)));
					sb.append(" ");
					sb.append(restriction.getOperand());
					sb.append(" and ");
				}
				sb.delete(sb.length() - 5, sb.length() - 1);
			}
		}

		PreparedStatement entityIdQuery = connection.prepareStatement(sb.toString());
		int index = 1;
		for (Restriction restriction : restrictionApplyOrder) {
			for (Object value : restriction.getValues()) {
				entityIdQuery.setObject(index++, value);
			}
		}

		ResultSet resultSet = entityIdQuery.executeQuery();
		Set<Object> result = new HashSet<Object>();
		while (resultSet.next()) {
			result.add(resultSet.getObject(1));
		}
		resultSet.close();
		return result;
	}

	private Map<List<Object>, List<Restriction>> parseRestrictions(List<Restriction> restrictions) {
		Map<List<Object>, List<Restriction>> entityRestrictions = new HashMap<List<Object>, List<Restriction>>();
		for (Restriction restriction : restrictions) {
			List<Object> restrictionKeys = restriction.getKeys();
			List<Object> mapKey = restrictionKeys.subList(0, restrictionKeys.size() - 1);
			List<Restriction> mapValue = entityRestrictions.get(mapKey);
			if (mapValue == null) {
				mapValue = new ArrayList<Restriction>();
				entityRestrictions.put(mapKey, mapValue);
			}
			mapValue.add(restriction);
		}
		return entityRestrictions;
	}

	private <T extends Entity<T>> Set<T> fetchEntities(Connection connection, Class<T> entity,
			Collection<Object> projections, Set<Object> ids) throws SQLException {
		if (ids.isEmpty()) return Collections.emptySet();

		StringBuilder sb = new StringBuilder(128);
		sb.append("select ");
		sb.append(dataMapper.getColumnName(entity, Entity.Field.Id));
		sb.append(",");
		for (Object projection : projections) {
			sb.append(dataMapper.getColumnName(entity, projection));
			sb.append(",");
		}
		sb.deleteCharAt(sb.length() - 1);
		sb.append(" from ");
		sb.append(dataMapper.getTableName(entity));
		sb.append(" where ");
		sb.append(dataMapper.getColumnName(entity, Entity.Field.Id));
		sb.append(" in (");
		for (int i = 0; i < ids.size(); i++) {
			sb.append("?,");
		}
		sb.deleteCharAt(sb.length() - 1);
		sb.append(")");

		PreparedStatement entityQuery = connection.prepareStatement(sb.toString());
		int index = 1;
		for (Object id : ids)
			entityQuery.setObject(index++, id);

		ResultSet resultSet = entityQuery.executeQuery();
		Set<T> result = new HashSet<T>();
		while (resultSet.next()) {
			Map<Object, Object> data = new HashMap<Object, Object>();
			data.put(Entity.Field.Id, resultSet.getObject(1));
			index = 2;
			for (Object projection : projections)
				data.put(projection, resultSet.getObject(index++));

			result.add(entityFactory.load(entity, data));
		}
		resultSet.close();
		return result;
	}
}