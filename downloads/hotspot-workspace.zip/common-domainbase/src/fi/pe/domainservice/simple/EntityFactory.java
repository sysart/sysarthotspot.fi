package fi.pe.domainservice.simple;

import java.util.Map;

import fi.pe.domain.Entity;

public interface EntityFactory {

	<T extends Entity<T>> T create(Class<T> entity);

	<T extends Entity<T>> T load(Class<T> entity, Map<Object, Object> data);

}
