package fi.pe.domainservice;

import java.io.Serializable;
import java.util.List;

public interface Restriction extends Serializable {

	List<Object> getKeys();

	String getOperand();

	List<Object> getValues();

}
