package fi.pe.domainservice;

import java.util.Collection;
import java.util.Set;

import fi.pe.domain.Entity;

public interface DomainService {

	<T extends Entity<T>> T create(Class<T> entity);

	<T extends Entity<T>> T save(T entity);

	<T extends Entity<T>> Set<T> execute(Class<T> entity, Collection<Projection> projections,
			Collection<Restriction> restrictions);

}
