package fi.pe.domainservice;

import java.io.Serializable;
import java.util.List;

public interface Projection extends Serializable {

	List<Object> getKeys();

}
